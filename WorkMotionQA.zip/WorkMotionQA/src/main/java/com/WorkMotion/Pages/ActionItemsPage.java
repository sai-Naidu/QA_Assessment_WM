package com.WorkMotion.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.WorkMotion.Utils.ElementUtils;

public class ActionItemsPage extends ElementUtils {
	
	//constructor
	public ActionItemsPage(WebDriver driver) {
		super(driver);
	}
	
	//objects of Action Items page
	private By actionItemsButton = By.xpath("//span[text()='Action Items']");
	
	//actions of Action Items page
	public void markAsDone(String input) {
		scrollToTheElement(actionItemsButton, "actionItemsButton");
		sleep("5");
		clickElement(actionItemsButton, "actionItemsButton");
		String xpathMarkAsDone = "(//span[contains(text(),'@names@')]//following::button)[1]";
		By MarkAsDoneButton = By.xpath(xpathMarkAsDone.replace("@names@", input));
		scrollToTheElement(MarkAsDoneButton, "MarkAsDoneButton");
		sleep("3");
		clickElement(MarkAsDoneButton, "MarkAsDoneButton");
	}
	
	//actions of Action Items page
	public String getCurrentStatus(String input) {
		String xpathDone = "(//h3[text()='Uncompleted actions']//following::span[contains(text(),'@names@')]//following::span)[1]";
		By doneText = By.xpath(xpathDone.replace("@names@", input));
		scrollToTheElement(doneText, "doneText");
		return getText(doneText, "doneText");
	}

}
