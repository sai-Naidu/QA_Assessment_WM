package com.WorkMotion.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.WorkMotion.Utils.ElementUtils;

public class LoginPage extends ElementUtils {
	
	//constructor
	public LoginPage(WebDriver driver) {
		super(driver);
	}
	
	//page objects
	private By emailInput = By.name("email");
	private By passwordInput = By.name("password");
	private By loginButton = By.xpath("//button[@type='submit']");
	
	//page actions
	public void doLogin(String email, String password) {
		sendValue(emailInput, email, "emailInput");
		sendValue(passwordInput, password, "passwordInput");
		clickElement(loginButton, "loginButton");
	}
	
	

}
