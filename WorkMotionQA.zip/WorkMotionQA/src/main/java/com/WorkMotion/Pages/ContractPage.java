package com.WorkMotion.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

import com.WorkMotion.Utils.ElementUtils;

public class ContractPage extends ElementUtils {
	
	//constructor
	public ContractPage(WebDriver driver) {
		super(driver);
	}
	
	//objects of Contract Details page
	private By firstNameInput = By.xpath("//input[contains(@placeholder,'first name')]");
	private By lastNameInput = By.xpath("//input[contains(@placeholder,'last name')]");
	private By eligibleToWorkRadio = By.xpath("(//span[contains(text(),'eligible to work')]//following::p)[1]");
	private By talentAnExecutiveRadio = By.xpath("(//span[contains(text(),'executive')]//following::p)[2]");
	private By jobTitleInput = By.xpath("(//span[text()='Job title']//following::input)[1]");
	private By jobDescriptionInput = By.xpath("//span[text()='Job description']//following::textarea");
	private By DirectManagerNamesInput = By.xpath("(//span[contains(text(),'First & last name of direct manager')]//following::input)[1]");
	private By DirectManagerTitleInput = By.xpath("(//span[contains(text(),'Title of direct manager')]//following::input)[1]");
	private By employmentTypeRadio = By.xpath("(//span[contains(text(),'Employment type')]//following::p)[1]");
	private By workingScheduleDropDown = By.xpath("//div[text()='Select...']");
	private By workingScheduleInput = By.xpath("//div[text()='Select...']//following::input[1]");
	private By contractStartDateInput = By.xpath("//input[@placeholder='DD-MM-YYYY']");
	private By ReimbursExpensesLabel =  By.xpath("//span[contains(text(),'Entity receiving')]");
	private By continueButton = By.xpath("//span[text()='Continue']");
	
	//objects of Contract Clauses page
	private By paidTimeOffAddButton = By.xpath("(//span[contains(text(),'Paid time off (PTO)')]//following::button)[2]");
	private By paidTimeOffSubButton = By.xpath("(//span[contains(text(),'Paid time off (PTO)')]//following::button)[1]");
	private By noticePeriodAddButton = By.xpath("(//span[contains(text(),'Termination Notice period')]//following::button)[2]");
	private By noticePeriodSubButton = By.xpath("(//span[contains(text(),'Termination Notice period')]//following::button)[1]");
	
	//objects of Salary Calculator page
	private By baseSalaryInput = By.xpath("(//span[contains(text(),'Base salary/month')]//following::input)[1]");
	private By overTimeRadioOne = By.xpath("(//span[contains(text(),'Overtime')]//following::p)[1]");
	private By calculateButton = By.name("calculate");
	
	//objects of invite Employee page
	private By talentEmailInput = By.xpath("(//span[contains(text(),'email')]//following::input)[1]");
	
	//objects of summary Review page
	private By serviceAgreementCheckbox = By.xpath("(//input[@id='serviceAgreement']//following::span)[1]");
	private By finishButton = By.xpath("(//button[@type='submit']/span)[1]");
	
	//actions of Contract Details page
	public void enterContractDetails(String...input) {
		sendValue(firstNameInput, input[0], "firstNameInput");
		sendValue(lastNameInput, input[1], "lastNameInput");
		clickElement(eligibleToWorkRadio, "eligibleToWorkRadio");
		clickElement(talentAnExecutiveRadio, "talentAnExecutiveRadio");
		sendValue(jobTitleInput, input[2], "jobTitleInput");
		clickAndSendValue(jobDescriptionInput, input[3], "jobDescriptionInput");
		sendValue(DirectManagerNamesInput, input[4], "DirectManagerNamesInput");
		sendValue(DirectManagerTitleInput, input[5], "DirectManagerTitleInput");
		clickElement(employmentTypeRadio, "employmentTypeRadio");
		clickElement(workingScheduleDropDown, "workingScheduleDropDown");
		sendValue(workingScheduleInput, input[6], "workingScheduleInput");
		sleep("2");
		pressKeys(Keys.TAB);
		scrollToTheElement(ReimbursExpensesLabel, "ReimbursExpensesLabel");
		clickAndSendValue(contractStartDateInput, input[7], "contractStartDateInput");
		sleep("2");
		clickElement(continueButton,"continueButton");
	}
	
	//actions of Contract Clauses page
	public void enterContractClauses(String... input) {
		int paidTimeOff = Integer.parseInt(input[0].split(":")[0]);
		int noticePeriod = Integer.parseInt(input[1].split(":")[0]);
		clickPlusOrMinusButton(input[0], paidTimeOff, paidTimeOffAddButton, paidTimeOffSubButton,"paidTimeOffAddButton","paidTimeOffSubButton");
		clickPlusOrMinusButton(input[1], noticePeriod, noticePeriodAddButton, noticePeriodSubButton,"noticePeriodAddButton","noticePeriodSubButton");
		clickElement(continueButton,"continueButton");
	}
	
	//actions of Salary Calculator page
	public void salaryCalculator(String... input) {
		sendValue(baseSalaryInput, input[0], "baseSalaryInput");
		clickElement(overTimeRadioOne, "overTimeRadioOne");
		clickElement(calculateButton, "calculateButton");
		clickElement(continueButton, "continueButton");
	}
	
	//actions of invite Employee page
	public void inviteEmployee(String... input) {
		sendValue(talentEmailInput, input[0], "talentEmailInput");
		clickElement(continueButton, "continueButton");
		
	}
	
	//actions of summary Review page
	public void summaryReview() {
		clickElement(serviceAgreementCheckbox, "serviceAgreementCheckbox");
		clickElement(finishButton, "finishButton");
	}

}
