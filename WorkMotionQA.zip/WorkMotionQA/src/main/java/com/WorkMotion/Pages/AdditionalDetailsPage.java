package com.WorkMotion.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.WorkMotion.Utils.ElementUtils;

public class AdditionalDetailsPage extends ElementUtils{
	
	//constructor
	public AdditionalDetailsPage(WebDriver driver) {
		super(driver);
	}
	
	//objects of Additional Details page
	private By emailAddressInput = By.name("financeContactEmail");
	private By managerFnameInput = By.name("managerDetails.firstName");
	private By managerLnameInput = By.name("managerDetails.lastName");
	private By managerEmailInput = By.name("managerDetails.email");
	private By finishButton = By.xpath("(//button[@type='submit']/span)[1]");
	private By congratsText = By.xpath("//h2[contains(text(),'Sit back and relax')]//preceding::h1[1]");
	
	//actions of Additional Details page
	public void enterAdditionalDetails(String... input) {
		sendValue(emailAddressInput, input[0], "emailAddressInput");
		sendValue(managerFnameInput, input[1], "managerFnameInput");
		sendValue(managerLnameInput, input[2], "managerLnameInput");
		sendValue(managerEmailInput, input[3], "managerEmailInput");
		clickElement(finishButton, "finishButton");
	}
	
	//actions of Additional Details page
	public String getCongratsMessage() {
		return getText(congratsText, "congratsText");
	}

}
