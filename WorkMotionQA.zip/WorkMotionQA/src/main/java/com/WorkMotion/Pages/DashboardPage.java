package com.WorkMotion.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

import com.WorkMotion.Utils.ElementUtils;

public class DashboardPage extends ElementUtils  {
	
	//constructor
	public DashboardPage(WebDriver driver) {
		super(driver);
	}

	//objects of Dashboard Page
	private By addEmployeeButton = By.xpath("//button[text()='Add employee']");
	private By createNewButton = By.xpath("//li[text()='CREATE NEW']");
	private By selectCountryInput = By.xpath("//div[text()='Select a country']");
	private By enterCountryInput = By.xpath("//input[@autocapitalize='none']");
	private By getStartedButton= By.xpath("(//button[@type='submit']/span)[1]");
	
	//actions of Dashboard Page
	public void selectAcountry(String countryName) throws InterruptedException {
		clickElement(addEmployeeButton,"addEmployeeButton");
		clickElement(createNewButton,"createNewButton");
		clickElement(selectCountryInput,"selectCountryInput");
		sendValue(enterCountryInput, countryName, "enterCountryInput");
		sleep("3");
		pressKeys(enterCountryInput, Keys.TAB, "enterCountryInput");
		scrollToTheElement(getStartedButton, "getStartedButton");
		sleep("3");
		clickElement(getStartedButton, "getStartedButton");
	}

}
