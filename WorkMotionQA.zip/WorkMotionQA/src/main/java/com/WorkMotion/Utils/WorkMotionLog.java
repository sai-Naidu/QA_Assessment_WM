package com.WorkMotion.Utils;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * This class is used to generate logs at runtime
 * @author hemasundarsai.n
 *
 */
public class WorkMotionLog {
	
	private static Logger Log = LogManager.getLogger(WorkMotionLog.class);
	
	public static void info(String message) {
		Log.info(message);
	}

	public static void error(String message) {
		Log.error(message);
	}
	

}
