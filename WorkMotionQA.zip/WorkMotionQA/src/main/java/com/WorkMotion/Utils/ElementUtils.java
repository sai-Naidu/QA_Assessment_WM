package com.WorkMotion.Utils;


import java.time.Duration;
import java.util.Properties;
import org.apache.commons.lang.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;


public class ElementUtils {
	
	private WebDriver driver;
	private ConfigReader configReader;
	Properties prop;
	
	/**
	 * Constructor of this class
	 * @param driver
	 */
	public ElementUtils(WebDriver driver) {
		this.driver=driver;
	}
	
	/**
	 * This method is used get the web Element after checking its presence and visibility
	 * @param locator
	 * @param locatorName
	 * @return this will return the webElement
	 * 
	 */
	
	public WebElement getElement(By locator, String locatorName) throws Exception {
		WebElement element = null;
		configReader = new ConfigReader();
		prop = configReader.init_prop();
		try {
			int time = Integer.parseInt(prop.getProperty("explicitWait"));
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(time));
			wait.until(ExpectedConditions.presenceOfElementLocated(locator));
			element = wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
			WorkMotionLog.info(locatorName + " is present and visible");
		} catch (Exception e) {
			WorkMotionLog.error(locatorName + " is either not present or not visible");
			Assert.fail(e.getMessage());
		}
		return element;
	}
	
	/**
	 * This method is used to click an element on web page
	 * @param locator
	 * @param locatorName
	 */
	public void clickElement(By locator, String locatorName) {
		try {
			getElement(locator,locatorName).click();
			WorkMotionLog.info("Clicked on "+ locatorName + " successfully");
		} catch (Exception e) {
			WorkMotionLog.error("Exception caught while clicking on "+ locatorName);
			Assert.fail(e.getMessage());
		}
	}
	
	/**
	 * This method is used to enter values in the web element
	 * @param locator
	 * @param value
	 * @param locatorName
	 */
	public void sendValue(By locator, String value, String locatorName) {
		try {
			getElement(locator,locatorName).sendKeys(value);
			WorkMotionLog.info("Entered "+value+" in "+ locatorName + " successfully");
		} catch (Exception e) {
			WorkMotionLog.error("Exception caught while clicking on entering the "+value+" in "+ locatorName );
			Assert.fail(e.getMessage());
		}
	}
	
	/**
	 * This method is used to clear the values in web element and enter values in the inside it
	 * @param locator
	 * @param value
	 * @param locatorName
	 */
	public void clearAndSendValue(By locator, String value, String locatorName) {
		try {
			clearValue(locator, locatorName);
			getElement(locator,locatorName).sendKeys(value);
			WorkMotionLog.info("Entered "+value+" in "+ locatorName + " successfully");
		} catch (Exception e) {
			WorkMotionLog.error("Exception caught while clicking on entering the "+value+" in "+ locatorName );
			Assert.fail(e.getMessage());
		}
	}
	
	/**
	 * This method is used to clear the values in the web element
	 * @param locator
	 * @param locatorName
	 */
	public void clearValue(By locator, String locatorName) {
		try {
			getElement(locator,locatorName).clear();
			WorkMotionLog.info("Cleared the value from "+ locatorName + " successfully");
		} catch (Exception e) {
			WorkMotionLog.error("Exception caught while clearing the value from "+ locatorName);
			Assert.fail(e.getMessage());
		}
	}
	
	/**
	 * This method is used to click the web element and enter values in it
	 * @param locator
	 * @param value
	 * @param locatorName
	 */
	public void clickAndSendValue(By locator, String value, String locatorName) {
		try {
			WebElement element = getElement(locator,locatorName);
			element.click();
			sleep("2");
			element.sendKeys(value);
			WorkMotionLog.info("Entered "+value+" in "+ locatorName + " successfully");
		} catch (Exception e) {
			WorkMotionLog.error("Exception caught while clicking on entering the "+value+" in "+ locatorName );
			Assert.fail(e.getMessage());
		}
	}
	
	/**
	 * This method is used to get the text if of a web element
	 * @param locator
	 * @param locatorName
	 * @return text
	 */
	public String getText(By locator, String locatorName) {
		String text = "";
		try {
			text = getElement(locator,locatorName).getText();
			WorkMotionLog.info("Got the text from "+ locatorName + " successfully");
		} catch (Exception e) {
			WorkMotionLog.error("Exception caught while getting the text from "+ locatorName);
			Assert.fail(e.getMessage());
		}
		return text;
	}
	
	/**
	 * This method is used to perform the keyboard operations on a web element
	 * @param locator
	 * @param key
	 * @param locatorName
	 */
	public void pressKeys(By locator, Keys key, String locatorName) {
		try {
			getElement(locator,locatorName).sendKeys(key);
			WorkMotionLog.info("Pressed the key on "+ locatorName + " successfully");
		} catch (Exception e) {
			WorkMotionLog.error("Exception caught while pressing the key "+ locatorName);
			Assert.fail(e.getMessage());
		}
	}
	
	/**
	 * This method is used to perform keyboard operations on a web page
	 * @param key
	 */
	public void pressKeys(Keys key) {
		try {
			Actions builder = new Actions(driver);
	        builder.sendKeys(key).build().perform();
	        WorkMotionLog.info("Pressed the key successfully");
		} catch (Exception e) {
			WorkMotionLog.error("Exception caught while pressing the key");
			Assert.fail(e.getMessage());
		}
	}
	
	/**
	 * This method is used to scroll to the web Element
	 * @param locator
	 * @param locatorName
	 */
	public void scrollToTheElement(By locator, String locatorName) {
		try {
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();",getElement(locator,locatorName));
			WorkMotionLog.info("Scolled to the "+ locatorName + " successfully");
		} catch (Exception e) {
			WorkMotionLog.error("Exception caught while scrolling to "+ locatorName);
			Assert.fail(e.getMessage());
		}
	}
	
	/**
	 * This method is used to click on + and - buttons on the application
	 * @param input
	 * @param condition
	 * @param locator1
	 * @param locator2
	 * @param locatorName1
	 * @param locatorName2
	 */
	public void clickPlusOrMinusButton(String input, int condition, By locator1, By locator2,String locatorName1, String locatorName2) {
		if(input.contains("plus")) {
			for(int i=1;i<=condition;i++) {
				clickElement(locator1,locatorName1);
				sleep("1");	
			}
		}
		else {
			for(int i=1;i<=condition;i++) {
				clickElement(locator2,locatorName2);
				sleep("1");	
			}
		}
	}
	
	/**
	 * This method is used to pause the execution of current thread for specified time
	 * @param seconds
	 */
	public void sleep(String seconds) {
		long millSec = (long)Integer.parseInt(seconds) * 1000;
		try {
			Thread.sleep(millSec);
		} catch (Exception ex) {
		}
	}
	
	/**
	 * This method is used to generate random string with specified length
	 * @param numberOfChars
	 * @return random string
	 */
	public String afgenerateRandomString(int numberOfChars) {
		String generatedString = RandomStringUtils.randomAlphabetic(numberOfChars);
		return generatedString;
	}
	

}
