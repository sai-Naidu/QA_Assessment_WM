package stepDefinitions;

import java.util.Properties;

import org.testng.Assert;

import com.WorkMotion.Pages.ActionItemsPage;
import com.WorkMotion.Pages.AdditionalDetailsPage;
import com.WorkMotion.Pages.ContractPage;
import com.WorkMotion.Pages.DashboardPage;
import com.WorkMotion.Pages.LoginPage;
import com.WorkMotion.Utils.ConfigReader;
import com.WorkMotion.Utils.DriverFactory;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

public class OnboardingSteps {
	private ConfigReader configReader = new ConfigReader();
	Properties prop;
	LoginPage lp = new LoginPage(DriverFactory.getDriver());
	DashboardPage dp = new DashboardPage(DriverFactory.getDriver());
	ContractPage cp = new ContractPage(DriverFactory.getDriver());
	AdditionalDetailsPage ap = new AdditionalDetailsPage(DriverFactory.getDriver());
    ActionItemsPage aip = new ActionItemsPage(DriverFactory.getDriver());
    
	String firstName = lp.afgenerateRandomString(7);
    String lastName = lp.afgenerateRandomString(5);
    String jobTitle = "Senior QA Automation Engineer";
    String jobDescription = "Task_1\\nTask_2\\nTask_3\\nTask_4\\nTask_5";
    String managerNames = "M"+firstName+" M"+lastName;
    String managerTitle = "Mr";
    String workingSchedule = "Fixed Hour";
    String contractStartDate = "10-03-2022";
    String contractDetails[]={firstName,lastName,jobTitle,jobDescription,managerNames,managerTitle,workingSchedule,contractStartDate};
    
	
	@Given("the HR manager login to application")
	public void the_hr_manager_login_to_application() {
		prop = configReader.init_prop();
		DriverFactory.getDriver().get(prop.getProperty("url"));
		lp.doLogin(prop.getProperty("userName"), prop.getProperty("password"));
	    
	}

	@Given("selcet the country as {string}")
	public void selcet_the_country_as(String country) throws Exception {
		dp.selectAcountry(country);
	}

	@Given("enter the contract details")
	public void enter_the_contract_details() {
		cp.enterContractDetails(contractDetails);
	}

	@Given("enter the contract clauses")
	public void enter_the_contract_clauses() {
		cp.enterContractClauses("9:plus","15:minus"); 
	}

	@Given("calculate the salary")
	public void calculate_the_salary() {
		cp.salaryCalculator("150000");
	    
	}

	@Given("invite the Employee")
	public void invite_the_employee() {
		cp.inviteEmployee(firstName+"@gmail.com");
	}

	@Then("review the summary")
	public void review_the_summary() {
		cp.summaryReview();
	}

	@Then("enter additional details")
	public void enter_additional_details() {
		ap.enterAdditionalDetails(firstName+"@gmail.com","M"+firstName,"M"+lastName,lastName+"@gmail.com");   
	}

	@Then("verify if the {string} message is displayed")
	public void verify_if_the_message_is_displayed(String string) {
		Assert.assertEquals(ap.getCongratsMessage(), "Congratulations, Onboarding has started!");
		aip.sleep("5"); 
	}

	@Then("mark the onboarding as done")
	public void mark_the_onboarding_as_done() {
		aip.markAsDone(firstName+" "+lastName);
		aip.sleep("20"); 
	}

	@Then("verify if {string} message is displayed")
	public void verify_if_message_is_displayed(String string) {
		Assert.assertEquals(aip.getCurrentStatus(firstName+" "+lastName), "DONE");     
	}
	
}
